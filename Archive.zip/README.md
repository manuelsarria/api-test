# apales_api_mail
This project is an API for Apales PTY that send mail
